import { useEffect, useRef } from "react";
import { StudentGrade } from "@/types/grade";
import { SUBJECT_NAMES } from "@/lib/grade-utils";

interface GradeChartProps {
  student: StudentGrade;
  isVisible: boolean;
}

declare global {
  interface Window {
    Chart: any;
  }
}

export function GradeChart({ student, isVisible }: GradeChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<any>(null);

  useEffect(() => {
    if (!isVisible || !chartRef.current || !window.Chart) return;

    // Destroy existing chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstanceRef.current = new window.Chart(ctx, {
      type: 'bar',
      data: {
        labels: SUBJECT_NAMES,
        datasets: [{
          label: 'Marks',
          data: student.subjects,
          backgroundColor: [
            'rgba(59, 130, 246, 0.8)',
            'rgba(16, 185, 129, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(239, 68, 68, 0.8)',
            'rgba(139, 92, 246, 0.8)'
          ],
          borderColor: [
            'rgba(59, 130, 246, 1)',
            'rgba(16, 185, 129, 1)',
            'rgba(245, 158, 11, 1)',
            'rgba(239, 68, 68, 1)',
            'rgba(139, 92, 246, 1)'
          ],
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context: any) {
                return `${context.label}: ${context.parsed.y}/100`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: {
              color: 'rgba(156, 163, 175, 0.3)'
            },
            ticks: {
              color: getComputedStyle(document.documentElement).getPropertyValue('--foreground')
            }
          },
          x: {
            grid: {
              color: 'rgba(156, 163, 175, 0.3)'
            },
            ticks: {
              color: getComputedStyle(document.documentElement).getPropertyValue('--foreground')
            }
          }
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [student, isVisible]);

  if (!isVisible) return null;

  return (
    <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
      <div className="relative h-64">
        <canvas ref={chartRef}></canvas>
      </div>
    </div>
  );
}
