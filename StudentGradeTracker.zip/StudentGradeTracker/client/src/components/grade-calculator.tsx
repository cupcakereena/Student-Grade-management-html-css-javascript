import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { StudentGrade, FormErrors } from "@/types/grade";
import { calculateGrade, calculateTotalMarks, calculatePercentage, SUBJECT_NAMES, validateMarks } from "@/lib/grade-utils";
import { addGradeToHistory } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

interface GradeCalculatorProps {
  onGradeCalculated: (grade: StudentGrade) => void;
}

export function GradeCalculator({ onGradeCalculated }: GradeCalculatorProps) {
  const [studentName, setStudentName] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [subjects, setSubjects] = useState<number[]>(Array(5).fill(0));
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!studentName.trim()) {
      newErrors.studentName = "Student name is required";
    }

    if (!rollNumber.trim()) {
      newErrors.rollNumber = "Roll number is required";
    }

    if (!validateMarks(subjects)) {
      newErrors.subjects = "All marks must be between 0-100";
    }

    if (subjects.some(mark => isNaN(mark))) {
      newErrors.subjects = "Please enter valid numbers for all subjects";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubjectChange = (index: number, value: string) => {
    const mark = parseInt(value) || 0;
    const newSubjects = [...subjects];
    newSubjects[index] = mark;
    setSubjects(newSubjects);
  };

  const clearForm = () => {
    setStudentName("");
    setRollNumber("");
    setSubjects(Array(5).fill(0));
    setErrors({});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      const totalMarks = calculateTotalMarks(subjects);
      const maxMarks = subjects.length * 100;
      const percentage = calculatePercentage(totalMarks, maxMarks);
      const gradeInfo = calculateGrade(percentage);

      const studentGrade: StudentGrade = {
        id: Date.now(),
        studentName: studentName.trim(),
        rollNumber: rollNumber.trim(),
        subjects,
        totalMarks,
        maxMarks,
        percentage: Math.round(percentage * 100) / 100,
        grade: gradeInfo.grade,
        gpa: gradeInfo.gpa,
        color: gradeInfo.color,
        timestamp: new Date().toLocaleString()
      };

      addGradeToHistory(studentGrade);
      onGradeCalculated(studentGrade);
      
      toast({
        title: "Grade Calculated Successfully",
        description: `${studentName} scored ${studentGrade.percentage}% (Grade: ${studentGrade.grade})`,
      });
      
      clearForm();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to calculate grade. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
          <i className="fas fa-calculator mr-3 text-blue-600"></i>
          Grade Entry System
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Student Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="student-name">
                <i className="fas fa-user mr-2"></i>Student Name
              </Label>
              <Input
                id="student-name"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="Enter student name"
                className={errors.studentName ? "border-red-500" : ""}
              />
              {errors.studentName && (
                <p className="text-red-500 text-sm">{errors.studentName}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="roll-number">
                <i className="fas fa-id-card mr-2"></i>Roll Number
              </Label>
              <Input
                id="roll-number"
                value={rollNumber}
                onChange={(e) => setRollNumber(e.target.value)}
                placeholder="Enter roll number"
                className={errors.rollNumber ? "border-red-500" : ""}
              />
              {errors.rollNumber && (
                <p className="text-red-500 text-sm">{errors.rollNumber}</p>
              )}
            </div>
          </div>

          {/* Subject Marks */}
          <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Subject Marks (out of 100)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SUBJECT_NAMES.map((subject, index) => (
                <div key={subject} className="space-y-2">
                  <Label htmlFor={`subject-${index}`}>{subject}</Label>
                  <Input
                    id={`subject-${index}`}
                    type="number"
                    min="0"
                    max="100"
                    value={subjects[index] || ""}
                    onChange={(e) => handleSubjectChange(index, e.target.value)}
                    placeholder="0-100"
                    className={errors.subjects ? "border-red-500" : ""}
                  />
                </div>
              ))}
            </div>
            {errors.subjects && (
              <Alert className="mt-4" variant="destructive">
                <AlertDescription>{errors.subjects}</AlertDescription>
              </Alert>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6">
            <Button 
              type="submit" 
              className="flex-1" 
              disabled={isSubmitting}
            >
              <i className="fas fa-calculator mr-2"></i>
              {isSubmitting ? "Calculating..." : "Calculate Grade"}
            </Button>
            <Button 
              type="button" 
              variant="secondary" 
              className="flex-1" 
              onClick={clearForm}
              disabled={isSubmitting}
            >
              <i className="fas fa-eraser mr-2"></i>
              Clear Form
            </Button>
          </div>
        </form>

        {/* Grade Legend */}
        <div className="mt-8 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
            <i className="fas fa-info-circle mr-2"></i>Grade Legend
          </h4>
          <div className="flex flex-wrap gap-3">
            <span className="px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full text-sm font-medium">
              A: 90-100%
            </span>
            <span className="px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full text-sm font-medium">
              B: 80-89%
            </span>
            <span className="px-3 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 rounded-full text-sm font-medium">
              C: 70-79%
            </span>
            <span className="px-3 py-1 bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200 rounded-full text-sm font-medium">
              D: 60-69%
            </span>
            <span className="px-3 py-1 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 rounded-full text-sm font-medium">
              F: Below 60%
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
