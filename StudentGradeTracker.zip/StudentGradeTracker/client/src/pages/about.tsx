import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const technologies = [
  {
    name: "HTML5",
    description: "Structure & Semantics",
    icon: "fab fa-html5",
    color: "orange"
  },
  {
    name: "CSS3 & Tailwind",
    description: "Styling & Responsive Design",
    icon: "fab fa-css3-alt",
    color: "blue"
  },
  {
    name: "JavaScript ES6+",
    description: "Logic & Interactivity",
    icon: "fab fa-js-square",
    color: "yellow"
  }
];

const features = [
  "Real-time grade calculation",
  "Interactive data visualization",
  "PDF export functionality",
  "Local storage integration",
  "Responsive design",
  "Dark/Light mode toggle",
  "Form validation",
  "Grade history tracking"
];

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">About GradeGen Pro</h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">Modern student grade management system</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          {/* Project Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-info-circle text-blue-600 mr-3"></i>
                Project Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Project Name</h3>
                <p className="text-gray-600 dark:text-gray-400">Student Grade Generating System</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Purpose</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Streamline academic performance evaluation with modern tools for educational institutions
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Target Users</h3>
                <p className="text-gray-600 dark:text-gray-400">Educators, teachers, and academic administrators</p>
              </div>
            </CardContent>
          </Card>

          {/* Developer Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-user-graduate text-green-600 mr-3"></i>
                Developer Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Student Name</h3>
                <p className="text-gray-600 dark:text-gray-400">Your Name Here</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Register Number</h3>
                <p className="text-gray-600 dark:text-gray-400">Your Register Number</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Department</h3>
                <p className="text-gray-600 dark:text-gray-400">Computer Science & Engineering</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Institution</h3>
                <p className="text-gray-600 dark:text-gray-400">Your Institution Name</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Technology Stack */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-code text-purple-600 mr-3"></i>
              Technology Stack
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {technologies.map((tech, index) => (
                <div key={index} className={`text-center p-6 bg-${tech.color}-50 dark:bg-${tech.color}-900/20 rounded-lg`}>
                  <i className={`${tech.icon} text-4xl text-${tech.color}-600 mb-3`}></i>
                  <h3 className="font-semibold text-gray-900 dark:text-white">{tech.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{tech.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Features List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-star text-yellow-600 mr-3"></i>
              Key Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <i className="fas fa-check-circle text-green-600"></i>
                  <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
