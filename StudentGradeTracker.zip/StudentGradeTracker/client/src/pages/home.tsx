import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: "fas fa-calculator",
    title: "Real-time Calculation",
    description: "Instant grade computation with comprehensive statistics and analytics",
    color: "blue"
  },
  {
    icon: "fas fa-chart-pie",
    title: "Visual Analytics",
    description: "Interactive charts and graphs for better performance insights",
    color: "green"
  },
  {
    icon: "fas fa-download",
    title: "PDF Export",
    description: "Generate professional grade reports for printing and sharing",
    color: "purple"
  },
  {
    icon: "fas fa-save",
    title: "Local Storage",
    description: "Automatically save and retrieve student grade history",
    color: "yellow"
  },
  {
    icon: "fas fa-mobile-alt",
    title: "Responsive Design",
    description: "Perfect experience across desktop, tablet, and mobile devices",
    color: "red"
  },
  {
    icon: "fas fa-palette",
    title: "Dark Mode",
    description: "Toggle between light and dark themes for comfortable viewing",
    color: "indigo"
  }
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 dark:from-blue-800 dark:via-blue-900 dark:to-gray-900">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
              Student Grade<br />
              <span className="text-yellow-300">Management System</span>
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto animate-slide-up">
              Streamline academic performance evaluation with our modern, intuitive grade calculation and management platform designed for educational institutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-bounce-subtle">
              <Button asChild size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-semibold">
                <Link href="/entry">
                  <i className="fas fa-plus mr-2"></i>Start Grading
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-800">
                <Link href="/about">
                  <i className="fas fa-info-circle mr-2"></i>Learn More
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Powerful Features</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">Everything you need to manage student grades efficiently</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-gray-50 dark:bg-gray-800 hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 bg-${feature.color}-100 dark:bg-${feature.color}-900 rounded-lg flex items-center justify-center mb-4`}>
                    <i className={`${feature.icon} text-${feature.color}-600 dark:text-${feature.color}-400 text-xl`}></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 dark:bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-400">&copy; 2024 GradeGen Pro. Built for educational excellence.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
