import { useState } from "react";
import { useLocation } from "wouter";
import { GradeCalculator } from "@/components/grade-calculator";
import { StudentGrade } from "@/types/grade";

export default function GradeEntry() {
  const [, setLocation] = useLocation();

  const handleGradeCalculated = (grade: StudentGrade) => {
    // Navigate to results page after calculation
    setLocation('/results');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Grade Entry System</h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">Enter student information and subject marks to calculate grades</p>
        </div>
        
        <GradeCalculator onGradeCalculated={handleGradeCalculated} />
      </div>
    </div>
  );
}
