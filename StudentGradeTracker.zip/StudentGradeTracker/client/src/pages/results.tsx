import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { GradeChart } from "@/components/grade-chart";
import { StudentGrade } from "@/types/grade";
import { SUBJECT_NAMES, getGradeColor, getGradeBgColor } from "@/lib/grade-utils";
import { loadGradeHistory } from "@/lib/storage";
import { exportToPDF } from "@/lib/pdf-export";
import { useToast } from "@/hooks/use-toast";

export default function Results() {
  const [currentStudent, setCurrentStudent] = useState<StudentGrade | null>(null);
  const [showChart, setShowChart] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Load the most recent grade from history
    const history = loadGradeHistory();
    if (history.length > 0) {
      setCurrentStudent(history[0]);
    }
  }, []);

  const handleDownloadPDF = async () => {
    if (!currentStudent) return;

    try {
      await exportToPDF(currentStudent, 'results-content');
      toast({
        title: "PDF Downloaded",
        description: "Grade report has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!currentStudent) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Grade Results</h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive analysis of student performance</p>
          </div>

          <div className="text-center py-20">
            <i className="fas fa-chart-bar text-6xl text-gray-400 mb-4"></i>
            <p className="text-xl text-gray-500 dark:text-gray-400">No results to display</p>
            <p className="text-gray-400 dark:text-gray-500 mb-6">Enter student grades to see detailed analysis</p>
            <Button asChild>
              <Link href="/entry">
                <i className="fas fa-plus mr-2"></i>Add New Entry
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Grade Results</h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive analysis of student performance</p>
        </div>

        <div id="results-content">
          <Card className="mb-8">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <CardTitle className="text-2xl">{currentStudent.studentName}</CardTitle>
                  <p className="text-gray-600 dark:text-gray-400">Roll Number: {currentStudent.rollNumber}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500">Generated on: {currentStudent.timestamp}</p>
                </div>
                <div className="flex space-x-3 mt-4 md:mt-0">
                  <Button onClick={handleDownloadPDF} variant="destructive">
                    <i className="fas fa-file-pdf mr-2"></i>Download PDF
                  </Button>
                  <Button onClick={() => setShowChart(!showChart)} variant="secondary">
                    <i className="fas fa-chart-bar mr-2"></i>
                    {showChart ? 'Hide Chart' : 'Show Chart'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Grade Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">{currentStudent.totalMarks}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Total Marks</div>
                  <div className="text-xs text-gray-500 dark:text-gray-500">out of {currentStudent.maxMarks}</div>
                </div>
                <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400">{currentStudent.percentage}%</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Percentage</div>
                </div>
                <div className={`${getGradeBgColor(currentStudent.grade)} p-6 rounded-lg text-center`}>
                  <div className={`text-3xl font-bold ${getGradeColor(currentStudent.grade)}`}>{currentStudent.grade}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Grade</div>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">{currentStudent.gpa}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">GPA</div>
                </div>
              </div>

              {/* Subject Breakdown */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Subject-wise Performance</h3>
                <div className="space-y-4">
                  {currentStudent.subjects.map((mark, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <span className="font-medium text-gray-900 dark:text-white">{SUBJECT_NAMES[index]}</span>
                      <div className="flex items-center space-x-3">
                        <Progress value={mark} className="w-32" />
                        <span className="text-lg font-semibold text-gray-900 dark:text-white w-12 text-right">{mark}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart */}
              {showChart && (
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Visual Analysis</h3>
                  <GradeChart student={currentStudent} isVisible={showChart} />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
