import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { StudentGrade } from "@/types/grade";
import { loadGradeHistory, removeGradeFromHistory, clearGradeHistory } from "@/lib/storage";
import { getGradeColor } from "@/lib/grade-utils";
import { useToast } from "@/hooks/use-toast";

export default function History() {
  const [history, setHistory] = useState<StudentGrade[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    setHistory(loadGradeHistory());
  }, []);

  const handleDeleteStudent = (id: number) => {
    const student = history.find(s => s.id === id);
    if (!student) return;

    if (confirm(`Are you sure you want to delete ${student.studentName}'s entry?`)) {
      const newHistory = removeGradeFromHistory(id);
      setHistory(newHistory);
      toast({
        title: "Entry Deleted",
        description: `${student.studentName}'s grade entry has been deleted.`,
      });
    }
  };

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear all history? This action cannot be undone.')) {
      clearGradeHistory();
      setHistory([]);
      toast({
        title: "History Cleared",
        description: "All grade history has been cleared.",
      });
    }
  };

  const handleViewStudent = (student: StudentGrade) => {
    // Store the selected student for viewing in results
    localStorage.setItem('selectedStudent', JSON.stringify(student));
    window.location.href = '/results';
  };

  if (history.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Grade History</h1>
              <p className="text-lg text-gray-600 dark:text-gray-400">View and manage all previously entered grades</p>
            </div>
          </div>

          <div className="text-center py-20">
            <i className="fas fa-history text-6xl text-gray-400 mb-4"></i>
            <p className="text-xl text-gray-500 dark:text-gray-400">No history available</p>
            <p className="text-gray-400 dark:text-gray-500 mb-6">Start entering grades to build your history</p>
            <Button asChild>
              <Link href="/entry">
                <i className="fas fa-plus mr-2"></i>Add New Entry
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Grade History</h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">View and manage all previously entered grades</p>
          </div>
          <Button onClick={handleClearHistory} variant="destructive">
            <i className="fas fa-trash mr-2"></i>Clear History
          </Button>
        </div>

        <Alert className="mb-6">
          <i className="fas fa-info-circle"></i>
          <AlertDescription>
            Found {history.length} grade {history.length === 1 ? 'entry' : 'entries'} in your history.
          </AlertDescription>
        </Alert>

        <div className="grid gap-6">
          {history.map((student) => (
            <Card key={student.id}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{student.studentName}</h3>
                    <p className="text-gray-600 dark:text-gray-400">Roll: {student.rollNumber}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500">{student.timestamp}</p>
                  </div>
                  <div className="flex items-center space-x-6 mt-4 md:mt-0">
                    <div className="text-center">
                      <div className="text-lg font-bold text-gray-900 dark:text-white">{student.percentage}%</div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">Percentage</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-lg font-bold ${getGradeColor(student.grade)}`}>{student.grade}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">Grade</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600 dark:text-purple-400">{student.gpa}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">GPA</div>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        onClick={() => handleViewStudent(student)}
                      >
                        <i className="fas fa-eye mr-1"></i>View
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        onClick={() => handleDeleteStudent(student.id)}
                      >
                        <i className="fas fa-trash mr-1"></i>Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
