export interface StudentGrade {
  id: number;
  studentName: string;
  rollNumber: string;
  subjects: number[];
  totalMarks: number;
  maxMarks: number;
  percentage: number;
  grade: string;
  gpa: number;
  color: string;
  timestamp: string;
}

export interface GradeInfo {
  grade: string;
  color: string;
  gpa: number;
}

export interface FormErrors {
  [key: string]: string;
}

export interface SubjectData {
  name: string;
  mark: number;
}
